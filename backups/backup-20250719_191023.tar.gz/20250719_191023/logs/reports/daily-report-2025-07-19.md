# 📊 MCP LLM Generator 日次運用レポート
**生成日時**: 2025年07月19日 19:07:17
**プロジェクト**: /home/mako10k/mcp-sampler

## 🖥️ システム概要
- **OS**: Ubuntu 24.04.2 LTS
- **アップタイム**: up 5 days, 30 minutes
- **Node.js**: v22.16.0
- **プロジェクトバージョン**: 1.0.1

## 📈 リソース使用状況
- **CPU負荷平均 (1分)**: 1.41
- **メモリ使用量**: 6294MB / 15965MB (39.4%)
- **ディスク使用量**: 29% (利用可能: 688G)

## 🔄 プロセス状況
- **MCPプロセス数**: 0 ⚠️
- **総プロセス数**: 130

## 🗄️ データベース状況
### context-memory.db
- **整合性**: ✅ OK
- **サイズ**: 696KB
- **テーブル数**: 8
- **テーブル別レコード数**:
  - contexts: 12件
  - conversations: 166件
  - personality_presets: 8件
  - persona_capabilities: 0件
  - persona_roles: 1件
  - persona_lineage: 0件
  - task_delegations: 0件
  - persona_merge_audit: 0件

### persona.db
- **整合性**: ✅ OK
- **サイズ**: 112KB
- **テーブル数**: 5
- **テーブル別レコード数**:
  - persona_capabilities: 3件
  - persona_roles: 3件
  - task_delegations: 0件
  - persona_lineage: 0件
  - contexts: 3件

### データベースサマリー
- **健全なDB数**: 2/2
- **総テーブル数**: 13
- **総サイズ**: 808KB

## 📋 ログ分析
- **ログディレクトリサイズ**: 1840KB
### 過去24時間のログ統計
- **エラー**: 8件
- **警告**: 2件
- **情報**: 1949件
### 最新のエラー例
- `/home/mako10k/mcp-sampler/logs/mcp_server.log:2025-07-18 10:42:15,850 [ERROR][mcp_assoc_memory.storage.metadata_store] Failed to set system setting 'embedding_provider': no such table: system_settings`
- `/home/mako10k/mcp-sampler/logs/mcp_server.log:2025-07-18 10:42:15,852 [ERROR][mcp_assoc_memory.storage.metadata_store] Failed to set system setting 'embedding_model': no such table: system_settings`
- `/home/mako10k/mcp-sampler/logs/mcp_server.log:2025-07-18 10:42:15,854 [ERROR][mcp_assoc_memory.storage.metadata_store] Failed to set system setting 'embedding_dimensions': no such table: system_settings`
- `/home/mako10k/mcp-sampler/logs/mcp_server.log:2025-07-18 10:42:15,856 [ERROR][mcp_assoc_memory.storage.metadata_store] Failed to set system setting 'embedding_config_hash': no such table: system_settings`
- `/home/mako10k/mcp-sampler/logs/mcp_server.log:2025-07-18 10:42:15,859 [ERROR][mcp_assoc_memory.storage.metadata_store] Failed to set system setting 'embedding_last_updated': no such table: system_settings`

## 🔒 セキュリティ監査
### ファイル権限監査
- ✅ ファイル権限: 問題なし
### 依存関係セキュリティ監査
- ⚠️ npm audit実行エラー

## ⚡ パフォーマンス分析
- **context-memory.db 応答時間**: 6ms
- **persona.db 応答時間**: 4ms
- **平均DB応答時間**: 5ms

## 💡 推奨事項
- ✅ 現在システムは良好に動作しています。定期監視を継続してください

## 📋 レポートサマリー
🟢 **総合状態**: 健全
- **総アラート数**: 1 (エラー: 0, 警告: 1)
- **生成時刻**: 2025-07-19 19:07:22
- **次回レポート予定**: 2025-07-20 09:00

---
*このレポートは `daily-report.sh` により自動生成されました*
